﻿using Quartz;
using System.Net.Http;
using System.Threading.Tasks;

namespace BotDailyTaskReminder
{
    public class ScheduleTaskReminder : IJob
    {
        static HttpClient client = new HttpClient();
        public async Task Execute(IJobExecutionContext context)
        {
            JobDataMap dataMap = context.JobDetail.JobDataMap;
            string baseUrl = dataMap.GetString("baseUrl");

            await client.GetAsync(baseUrl + "/api/task");
        }
    }
}