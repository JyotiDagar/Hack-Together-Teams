using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BotDailyTaskReminder.Pages
{
    public class ScheduleTaskModel
        : PageModel
    {
        public void OnGet()
        {
        }
    }
}
